@extends('layout.main')
@section('content')
    @livewire('admin.user.user-create')
@endsection