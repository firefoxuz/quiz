@extends('layout.main')
@section('content')
    @livewire('admin.quiz.create')
@endsection