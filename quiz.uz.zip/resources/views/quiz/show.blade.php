@extends('layout.main')
@section('content')
        @livewire('admin.quiz.show', ['quiz' => $quiz])
@endsection