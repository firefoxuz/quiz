<nav id="sidebar" class="card redial-border-light px-2 mb-4">
    <div class="sidebar-scrollarea">
        <ul class="metismenu list-unstyled mb-0" id="menu">
            <li><a href="<?php echo e(route('home')); ?>"><i class="fa fa-dashboard pr-1"></i> Dashboard</a></li>
            <li>
                <a class="has-arrow" href="#" data-toggle="collapse" aria-expanded="false"><i
                            class="icofont icofont-ui-user pr-1"></i> <?php echo e(__('data.user.user')); ?></a>
                <ul class="collapse list-unstyled">
                    <li><a href="<?php echo e(route('user.index')); ?>" class="icofont icofont-list"> <?php echo e(__('data.user.list')); ?></a></li>
                    <li><a href="<?php echo e(route('user.create')); ?>" class="icofont icofont-plus"> <?php echo e(__('data.user.new')); ?></a></li>
                </ul>
            </li>
            <li>
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <a onclick="" ><i class="icofont icofont-exit"></i> <?php echo e(__('data.site.logout')); ?></a>
                </form>
            </li>
        </ul>
    </div>
</nav>
<?php /**PATH E:\OpenServer\domains\dic.firefox.uz\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>