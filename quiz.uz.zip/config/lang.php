<?php
return [
    'uz' => 'Uzbek',
    'en' => 'English'
];