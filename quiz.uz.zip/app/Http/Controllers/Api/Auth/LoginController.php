<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Api\BaseController;
use App\Traits\ApiResponser;
use Auth;
use Carbon\Carbon;
use Illuminate\Http\Request;

/**
 * @OA\Post(
 *     summary="Login a user",
 *     path="/api/login",
 *     description="Login a user",
 *     tags={"Auth"},
 *     @OA\RequestBody(
 *         required=true,
 *         description="pass user credentials",
 *         @OA\JsonContent(
 *             required={"email", "password"},
 *             @OA\Property(property="email", type="string", format="email", example="admin@admin.com"),
 *             @OA\Property(property="password", type="string", format="password", example="Password123"),
 *     ),
 * ),
 *     @OA\Response(
 *      response="200",
 *      description="User created successfully",
 *      @OA\JsonContent(
 *         @OA\Property(property="status", type="string", example="success"),
 *         @OA\Property(property="message", type="null", example="null"),
 *         @OA\Property(property="data", type="object",
 *              @OA\Property(property="token", type="string", example="CzU5Acl5F35dDLZkSJpgvUbPJJwPMZwnM0x2KSIo"),
 *         ),
 *      ),
 *     ),
 *     @OA\Response(
 *      response="401",
 *      description="Credentials are not correct",
 *      @OA\JsonContent(
 *         @OA\Property(property="status", type="string", example="error"),
 *         @OA\Property(property="message", type="string", example="Credentials not match"),
 *         @OA\Property(property="data", type="string", example="null"),
 *         ),
 *      ),
 *     @OA\Response(
 *      response="422",
 *      description="The given data was invalid",
 *      @OA\JsonContent(
 *         @OA\Property(property="message", type="string", example="The given data was invalid."),
 *         @OA\Property(property="errors", type="object",
 *              @OA\Property(property="email", type="array",
 *                 @OA\Items(type="string", example="The email has already been taken.")),
 *              @OA\Property(property="password", type="array",
 *                 @OA\Items(type="string", example="The password must be at least 6 characters.")),
 *         ),
 *      ),
 *     ),
 * ),
 * )
 */
class LoginController extends BaseController
{
    use ApiResponser;

    public function authenticate(Request $request)
    {
        $attr = $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string|min:6'
        ]);

        if (!Auth::guard('api')->attempt($attr)) {
            return $this->error('Credentials not match', 401);
        }
        auth('api')->user()->update(['last_login' => Carbon::now()->toDateTimeString()]);
        return $this->success([
            'token' => auth('api')->user()->createToken('API Token')->plainTextToken
        ]);
    }
}