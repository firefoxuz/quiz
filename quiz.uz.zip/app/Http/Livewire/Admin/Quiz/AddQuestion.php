<?php

namespace App\Http\Livewire\Admin\Quiz;

use App\Models\QuizQuestion;
use App\Repository\Admin\Quiz\EloquentQuizQuestionRepository;
use App\Services\DBTransaction;
use App\Services\SweetAlert;
use Livewire\Component;

class AddQuestion extends Component
{
    public $quiz_id;

    public $type;
    public $level;
    public $score;
    public $content;

    protected $rules = [
        'type' => 'required|integer|min:0|max:3',
        'level' => 'required|integer|min:1|max:3',
        'score' => 'required|integer|min:1|max:100',
        'content' => 'required|min:3|string|max:1000',
    ];

    public function mount($quiz_id)
    {
        $this->quiz_id = $quiz_id;
    }


    public function create()
    {
        $data = $this->validate();

        DBTransaction::run(function () use ($data) {
            (new EloquentQuizQuestionRepository())->create([
                'quiz_id' => $this->quiz_id,
                'type' => $data['type'],
                'level' => $data['level'],
                'score' => $data['score'],
                'content' => $data['content'],
            ]);
            SweetAlert::alertSuccess($this, 'created successfully');
        }, function ($exception) {
            SweetAlert::alertError($this, $exception->getMessage());
        });

        $this->reset([
            'type',
            'level',
            'score',
            'content',
        ]);
    }


    public function render()
    {
        return view('livewire.admin.quiz.add-question',[
            'types' => QuizQuestion::TYPES,
            'levels' => QuizQuestion::LEVELS,
        ]);
    }
}
