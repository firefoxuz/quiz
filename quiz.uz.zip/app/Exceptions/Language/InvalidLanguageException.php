<?php


namespace App\Exceptions\Language;


class InvalidLanguageException extends \Exception
{

}