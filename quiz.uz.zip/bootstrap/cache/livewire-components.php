<?php return array (
  'admin.quiz-answer.add-answer' => 'App\\Http\\Livewire\\Admin\\QuizAnswer\\AddAnswer',
  'admin.quiz-question.show' => 'App\\Http\\Livewire\\Admin\\QuizQuestion\\Show',
  'admin.quiz.add-question' => 'App\\Http\\Livewire\\Admin\\Quiz\\AddQuestion',
  'admin.quiz.create' => 'App\\Http\\Livewire\\Admin\\Quiz\\Create',
  'admin.quiz.index' => 'App\\Http\\Livewire\\Admin\\Quiz\\Index',
  'admin.quiz.show' => 'App\\Http\\Livewire\\Admin\\Quiz\\Show',
  'admin.user.api-user.create' => 'App\\Http\\Livewire\\Admin\\User\\ApiUser\\Create',
  'admin.user.api-user.index' => 'App\\Http\\Livewire\\Admin\\User\\ApiUser\\Index',
  'admin.user.api-user.update' => 'App\\Http\\Livewire\\Admin\\User\\ApiUser\\Update',
  'admin.user.user-create' => 'App\\Http\\Livewire\\Admin\\User\\UserCreate',
  'admin.user.user-index' => 'App\\Http\\Livewire\\Admin\\User\\UserIndex',
);